﻿namespace Hahn.ApplicationProcess.December2020.Domain.Models
{
    public class Country
    {
        public string Name { get; set; }

    }

}