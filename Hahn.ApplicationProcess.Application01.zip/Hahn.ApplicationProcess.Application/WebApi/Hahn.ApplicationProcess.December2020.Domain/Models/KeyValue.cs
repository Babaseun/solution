﻿namespace Hahn.ApplicationProcess.December2020.Domain.Models
{
    public class KeyValue
    {
        public string PropertyName { get; set; }
        public string PropertyValue { get; set; }
        public bool HasValidationErrors { get; set; }
    }
}
