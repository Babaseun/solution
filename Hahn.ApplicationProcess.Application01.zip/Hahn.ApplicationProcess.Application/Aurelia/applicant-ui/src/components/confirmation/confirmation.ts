export class Confirmation {
  message: string;

  constructor() {
    this.message = 'Applicant saved successfully';
  }
}
